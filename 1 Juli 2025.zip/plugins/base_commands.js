// plugins/base_commands.js

export default async function baseCommandsPlugin(sock) {
    console.log('[PLUGIN] Base Commands siap.');

    // Mengembalikan fungsi yang akan dipanggil ketika ada pesan
    return async (msg, text, lowerText, senderNumber, isOwner) => {
        if (!isOwner && lowerText.startsWith('!')) { // Jika bukan owner dan itu perintah
            return false; // Owner check sudah menangani, jangan proses lebih lanjut
        }

        if (lowerText === '!ping') {
            await sock.sendMessage(msg.key.remoteJid, { text: 'pong' }, { quoted: msg });
            console.log(`[BASE_COMMANDS] Respon 'pong' ke ${msg.key.remoteJid}`);
            return true; // Pesan ini sudah ditangani
        }
        return false; // Pesan ini tidak ditangani oleh plugin ini
    };
}