// plugins/group_info.js
import fs from 'fs/promises'; // Import module fs untuk membaca file

export default async function groupInfoPlugin(sock) {
    console.log('[PLUGIN] Group Info siap.');

    // Fungsi untuk membaca daftar grup dari pantaugrup.txt
    const getMonitoredGroupIds = async () => {
        try {
            const data = await fs.readFile('./pantaugrup.txt', 'utf8');
            // Filter baris kosong dan trim spasi
            return new Set(data.split('\n').map(line => line.trim()).filter(line => line.length > 0));
        } catch (error) {
            if (error.code === 'ENOENT') {
                console.warn('[GROUP_INFO] File pantaugrup.txt tidak ditemukan. Menganggap tidak ada grup yang dipantau.');
                return new Set(); // Kembalikan Set kosong jika file tidak ada
            }
            console.error('[ERROR - GROUP_INFO] Gagal membaca pantaugrup.txt:', error);
            return new Set();
        }
    };

    return async (msg, text, lowerText, senderNumber, isOwner, isGroup) => {
        const remoteJid = msg.key.remoteJid;

        // --- Perintah Owner Saja ---
        if (lowerText.startsWith('!idgrup') || lowerText.startsWith('!idgruplist') || lowerText.startsWith('!scangrup') || lowerText.startsWith('!scanpantau')) {
            if (!isOwner) {
                // Owner check sudah mengirim pesan "Anda bukan owner"
                return false;
            }
        }

        // --- Logika !idgrup (Revisi: Per grup per pesan) ---
        if (lowerText === '!idgrup') {
            try {
                const allGroups = await sock.groupFetchAllParticipating();
                let groupCount = 0;

                for (const jid in allGroups) {
                    const group = allGroups[jid];
                    const groupName = group.subject;
                    const groupId = group.id;
                    await sock.sendMessage(remoteJid, { text: `${groupName}|${groupId}` }); // Tidak perlu quoted: msg
                    groupCount++;
                    await new Promise(resolve => setTimeout(resolve, 1000)); // Delay 1 detik antar pesan untuk menghindari flood
                }

                if (groupCount === 0) {
                    await sock.sendMessage(remoteJid, { text: "Bot tidak bergabung di grup manapun." }, { quoted: msg });
                } else {
                    console.log(`[GROUP_INFO] Info ${groupCount} grup dikirim secara terpisah.`);
                }
            } catch (error) {
                console.error('[ERROR - GROUP_INFO] Gagal mendapatkan info grup secara terpisah:', error);
                await sock.sendMessage(remoteJid, { text: 'Terjadi kesalahan saat mencoba mendapatkan info grup.' }, { quoted: msg });
            }
            return true;
        }

        // --- Logika !idgruplist (Tetap satu pesan mencakup semua grup) ---
        if (lowerText === '!idgruplist') {
            try {
                const allGroups = await sock.groupFetchAllParticipating();
                let responseText = "*Daftar Grup Bot:*\n\n";
                let groupCount = 0;

                for (const jid in allGroups) {
                    const group = allGroups[jid];
                    responseText += `• ${group.subject} | ${group.id}\n`;
                    groupCount++;
                }

                if (groupCount === 0) {
                    responseText = "Bot tidak bergabung di grup manapun.";
                }

                await sock.sendMessage(remoteJid, { text: responseText.trim() }, { quoted: msg });
                console.log(`[GROUP_INFO] Daftar ${groupCount} grup dikirim.`);
            } catch (error) {
                console.error('[ERROR - GROUP_INFO] Gagal mendapatkan daftar grup:', error);
                await sock.sendMessage(remoteJid, { text: 'Terjadi kesalahan saat mencoba mendapatkan daftar grup.' }, { quoted: msg });
            }
            return true;
        }

        // --- Logika !scangrup ---
        if (lowerText === '!scangrup') {
            try {
                const allGroups = await sock.groupFetchAllParticipating();
                let responseText = "*Hasil Scan Grup Bot:*\n\n";
                let groupCount = 0;

                for (const jid in allGroups) {
                    const group = allGroups[jid];
                    const creationDate = new Date(group.creation * 1000).toLocaleDateString('id-ID'); // Konversi timestamp ke tanggal
                    responseText += `*Nama Grup:* ${group.subject}\n`;
                    responseText += `*ID Grup:* ${group.id}\n`;
                    responseText += `*Jumlah Anggota:* ${group.participants.length}\n`;
                    responseText += `*Dibuat Pada:* ${creationDate}\n`;
                    responseText += `-----------------------------------\n`;
                    groupCount++;
                }

                if (groupCount === 0) {
                    responseText = "Bot tidak bergabung di grup manapun.";
                }

                await sock.sendMessage(remoteJid, { text: responseText.trim() }, { quoted: msg });
                console.log(`[GROUP_INFO] Hasil scan ${groupCount} grup dikirim.`);
            } catch (error) {
                console.error('[ERROR - GROUP_INFO] Gagal melakukan scan grup:', error);
                await sock.sendMessage(remoteJid, { text: 'Terjadi kesalahan saat mencoba melakukan scan grup.' }, { quoted: msg });
            }
            return true;
        }

        // --- Logika !scanpantau ---
        if (lowerText === '!scanpantau') {
            try {
                const monitoredGroupIds = await getMonitoredGroupIds();
                const allParticipatingGroups = await sock.groupFetchAllParticipating();
                let unmonitoredGroups = [];

                for (const jid in allParticipatingGroups) {
                    const group = allParticipatingGroups[jid];
                    if (!monitoredGroupIds.has(group.id)) {
                        unmonitoredGroups.push({
                            name: group.subject,
                            id: group.id
                        });
                    }
                }

                let responseText = "*Grup Tidak Terdaftar di pantaugrup.txt:*\n\n";
                if (unmonitoredGroups.length === 0) {
                    responseText += "Semua grup yang diikuti bot sudah terdaftar di pantaugrup.txt.";
                } else {
                    for (const group of unmonitoredGroups) {
                        responseText += `• *Nama:* ${group.name}\n  *ID:* ${group.id}\n\n`;
                    }
                }

                await sock.sendMessage(remoteJid, { text: responseText.trim() }, { quoted: msg });
                console.log(`[GROUP_INFO] Hasil scan pantau grup dikirim. Ditemukan ${unmonitoredGroups.length} grup tidak terpantau.`);
            } catch (error) {
                console.error('[ERROR - GROUP_INFO] Gagal menjalankan !scanpantau:', error);
                await sock.sendMessage(remoteJid, { text: 'Terjadi kesalahan saat mencoba memindai grup yang tidak terpantau.' }, { quoted: msg });
            }
            return true;
        }


        return false; // Pesan tidak ditangani oleh plugin ini
    };
}