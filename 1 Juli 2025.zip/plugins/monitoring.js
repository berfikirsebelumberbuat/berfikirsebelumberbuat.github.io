// plugins/monitoring.js

import { isMonitoring } from '../config.js'; // Ambil isMonitoring dari config
// Import 'watchFile' dari utils.js
import { sendToTelegram, readListFromFile, appendToFile, watchFile } from '../utils.js'; 

let currentIsMonitoring = isMonitoring; // Salinan mutable dari isMonitoring
let monitoredGroups = new Set();
let whitelistNumbers = new Set(); // Diperlukan untuk logika monitoring

export default async function monitoringPlugin(sock) {
    console.log('[PLUGIN] Monitoring siap.');

    // Muat daftar grup dan whitelist di awal
    monitoredGroups = await readListFromFile('pantaugrup.txt', 'MONITORING_GROUPS');
    whitelistNumbers = await readListFromFile('whitelist.txt', 'MONITORING_WHITELIST');

    // --- Pemantauan Perubahan File Otomatis ---
    // Memantau pantaugrup.txt dan memperbarui monitoredGroups saat ada perubahan
    watchFile('pantaugrup.txt', (newList) => {
        monitoredGroups = newList;
        console.log('[MONITORING] Daftar grup pemantauan diperbarui secara otomatis dari pantaugrup.txt.');
    });

    // Memantau whitelist.txt dan memperbarui whitelistNumbers saat ada perubahan
    watchFile('whitelist.txt', (newList) => {
        whitelistNumbers = newList;
        console.log('[MONITORING] Daftar whitelist diperbarui secara otomatis dari whitelist.txt.');
    });
    // ------------------------------------------

    // Mengembalikan fungsi yang akan dipanggil ketika ada pesan
    return async (msg, text, lowerText, senderNumber, isOwner, isGroup) => {
        // --- Logika Pemantauan Grup & Whitelist ---
        if (currentIsMonitoring && isGroup && monitoredGroups.has(msg.key.remoteJid)) {
            if (whitelistNumbers.has(senderNumber)) {
                console.log(`[MONITORING] Nomor ${senderNumber} ada di whitelist, notifikasi diabaikan.`);
            } else {
                console.log(`[MONITORING] Pemantauan aktif. Grup ${msg.key.remoteJid} ada di daftar pantau.`);
                const messageToSend = `/crash ${senderNumber}`;
                console.log(`[MONITORING] Mengirim notifikasi ke Telegram: "${messageToSend}" dari grup ${msg.key.remoteJid}`);
                await sendToTelegram(messageToSend);
            }
            if (!lowerText.startsWith('!')) {
                 return true;
            }
        } else {
            console.log(`[MONITORING] Pemantauan tidak aktif, bukan dari grup, atau grup ${msg.key.remoteJid} tidak dipantau.`);
        }
        // -----------------------------------------

        // --- Penanganan Perintah Monitoring (Hanya untuk Owner) ---
        if (!isOwner && lowerText.startsWith('!')) {
            return false;
        }

        if (lowerText.startsWith('!pantaugrup ')) {
            const parts = text.split(' ');
            if (parts.length < 2) {
                await sock.sendMessage(msg.key.remoteJid, { text: 'Format salah. Gunakan: !pantaugrup on/off atau !pantaugrup idgrup@g.us' }, { quoted: msg });
                console.log('[MONITORING] Format !pantaugrup salah.');
                return true;
            }

            const commandArgument = parts[1];

            if (commandArgument.toLowerCase() === 'on') {
                currentIsMonitoring = true;
                await sock.sendMessage(msg.key.remoteJid, { text: 'Pemantauan grup diaktifkan.' }, { quoted: msg });
                console.log('[MONITORING] Pemantauan grup diaktifkan.');
                return true;
            } else if (commandArgument.toLowerCase() === 'off') {
                currentIsMonitoring = false;
                await sock.sendMessage(msg.key.remoteJid, { text: 'Pemantauan grup dinonaktifkan.' }, { quoted: msg });
                console.log('[MONITORING] Pemantauan grup dinonaktifkan.');
                return true;
            } else {
                const groupId = commandArgument;
                if (!groupId.endsWith('@g.us')) {
                    await sock.sendMessage(msg.key.remoteJid, { text: 'ID grup tidak valid. Pastikan berakhiran @g.us' }, { quoted: msg });
                    console.log('[MONITORING] ID grup tidak valid pada !pantaugrup command.');
                    return true;
                }

                try {
                    if (!monitoredGroups.has(groupId)) {
                        await appendToFile('pantaugrup.txt', groupId);
                        // Penting: Update Set di memori langsung setelah menulis ke file
                        monitoredGroups.add(groupId); 
                        await sock.sendMessage(msg.key.remoteJid, { text: `ID grup ${groupId} telah ditambahkan ke pantaugrup.txt` }, { quoted: msg });
                        console.log(`[MONITORING] ID grup ${groupId} ditambahkan ke pantaugrup.txt.`);
                    } else {
                        await sock.sendMessage(msg.key.remoteJid, { text: `ID grup ${groupId} sudah ada dalam daftar pemantauan.` }, { quoted: msg });
                        console.log(`[MONITORING] ID grup ${groupId} sudah ada.`);
                    }
                } catch (error) {
                    console.error('[ERROR - MONITORING] Error menulis ke pantaugrup.txt:', error);
                    await sock.sendMessage(msg.key.remoteJid, { text: 'Terjadi kesalahan saat menyimpan ID grup.' }, { quoted: msg });
                }
                return true;
            }
        }

        // --- Perintah baru: !cekpantaugrup ---
        if (lowerText === '!cekpantaugrup') {
            const status = currentIsMonitoring ? 'On' : 'Off';
            await sock.sendMessage(msg.key.remoteJid, { text: `Pemantauan grup saat ini: *${status}*` }, { quoted: msg });
            console.log(`[MONITORING] Status pemantauan grup diminta: ${status}.`);
            return true;
        }
        // ------------------------------------

        return false;
    };
}

// Fungsi untuk memperbarui daftar whitelist dari luar plugin (misalnya dari whitelist.js)
// Fungsi ini masih bisa digunakan, tetapi pembaruan dari file akan ditangani oleh watchFile
export async function refreshWhitelist(newWhitelist) {
    whitelistNumbers = newWhitelist;
    console.log('[MONITORING] Daftar whitelist diperbarui secara manual.');
}