// plugins/autojoingrup.js

// 1. Impor Modul yang Dibutuhkan
import { readListFromFile, appendToFile } from '../utils.js';

// 2. Deklarasi Variabel Internal Plugin
// Set untuk menyimpan link grup yang sudah pernah di-join agar tidak duplikat
let joinedGroupLinks = new Set();
const GROUP_LINKS_FILE = 'linkgrupwhatsapp.txt';

// 3. Fungsi Default Export (Fungsi Utama Plugin)
export default async function autojoingrup(sock) {
    console.log(`[PLUGIN] ${autojoingrup.name} siap.`);

    // 3.1. Inisialisasi Plugin
    // Baca daftar link grup yang sudah di-join dari file saat plugin dimuat
    const existingLinks = await readListFromFile(GROUP_LINKS_FILE, 'AUTOJOIN_GRUP');
    existingLinks.forEach(link => joinedGroupLinks.add(link));
    console.log(`[${autojoingrup.name}] Memuat ${joinedGroupLinks.size} link grup yang sudah di-join.`);

    // 3.2. Kembalikan Fungsi Handler Pesan
    return async (msg, text, lowerText, senderNumber, isOwner, isGroup) => {
        // Abaikan pesan jika itu adalah pesan yang dikirim oleh bot itu sendiri
        if (msg.key.fromMe) {
            return false;
        }

        const whatsappInviteRegex = /(https:\/\/chat\.whatsapp\.com\/[a-zA-Z0-9]{22})/g;
        const matches = text.match(whatsappInviteRegex);

        if (matches && matches.length > 0) {
            for (const inviteLink of matches) {
                const cleanLink = inviteLink.trim();

                // Cek apakah link sudah ada di Set (sudah pernah di-join)
                if (joinedGroupLinks.has(cleanLink)) {
                    console.log(`[${autojoingrup.name}] [INFO] Link grup sudah pernah di-join: ${cleanLink}`);
                    return true; // Pesan ini dianggap sudah ditangani
                }

                console.log(`[${autojoingrup.name}] [DETEKSI] Link grup terdeteksi: ${cleanLink}`);

                try {
                    const code = cleanLink.split('/').pop(); // Ambil kode undangan dari link
                    const response = await sock.groupAcceptInvite(code);

                    // Logika yang lebih robust untuk mendeteksi keberhasilan join.
                    if (response && (typeof response === 'string' || (typeof response === 'object' && response.gid))) {
                        const groupId = typeof response === 'string' ? response : response.gid; // Ambil ID grup
                        console.log(`[${autojoingrup.name}] [BERHASIL] Bergabung ke grup: ${groupId} dari link: ${cleanLink}`);

                        // Tambahkan link ke Set dan simpan ke file
                        joinedGroupLinks.add(cleanLink);
                        await appendToFile(GROUP_LINKS_FILE, cleanLink, 'AUTOJOIN_GRUP');
                        return true; // Penting: Kembali 'true' setelah berhasil
                    } else {
                        // Jika respons Baileys tidak seperti yang diharapkan untuk sukses
                        console.error(`[${autojoingrup.name}] [GAGAL] Bergabung ke grup dari link: ${cleanLink}. Respon tidak valid atau tidak menunjukkan keberhasilan. Respon:`, JSON.stringify(response));
                        return true; // Pesan tetap dianggap ditangani (meskipun gagal)
                    }
                } catch (error) {
                    // Penanganan error jaringan atau API yang sebenarnya
                    console.error(`[${autojoingrup.name}] [ERROR] Saat mencoba bergabung ke grup ${cleanLink}:`, error);
                    return true; // Pesan tetap dianggap ditangani
                }
            }
        }

        // 5. Kembalikan 'false' Jika Tidak Ada yang Ditangani
        return false;
    };
}