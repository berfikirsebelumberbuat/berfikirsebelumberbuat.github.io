// plugins/pesan_grup_nomor.js

import fs from 'fs/promises';
import { sendToTelegram, normalizeNumber } from '../utils.js';

let monitoredGroups = new Set();
let whitelistNumbers = new Set();

export default async function pesanGrupNomorPlugin(sock) {
    console.log('[PLUGIN] Pesan Grup Nomor siap.');

    const loadMonitoredGroups = async () => {
        try {
            const data = await fs.readFile('./pantaugrup.txt', 'utf8');
            monitoredGroups = new Set(data.split('\n').map(id => id.trim()).filter(id => id.length > 0));
            console.log('[PESAN_GRUP_NOMOR] Grup dipantau dimuat:', [...monitoredGroups]);
        } catch (error) {
            if (error.code === 'ENOENT') {
                await fs.writeFile('./pantaugrup.txt', '', 'utf8');
                console.log('[PESAN_GRUP_NOMOR] pantaugrup.txt tidak ditemukan, membuat baru.');
                monitoredGroups = new Set();
            } else {
                console.error('[ERROR - PESAN_GRUP_NOMOR] Gagal membaca pantaugrup.txt:', error);
            }
        }
    };

    const loadWhitelistNumbers = async () => {
        try {
            const data = await fs.readFile('./whitelist.txt', 'utf8');
            whitelistNumbers = new Set(data.split('\n').map(num => num.trim()).filter(num => num.length > 0));
            console.log('[PESAN_GRUP_NOMOR] Whitelist dimuat:', [...whitelistNumbers]);
        } catch (error) {
            if (error.code === 'ENOENT') {
                await fs.writeFile('./whitelist.txt', '', 'utf8');
                console.log('[PESAN_GRUP_NOMOR] whitelist.txt tidak ditemukan, membuat baru.');
                whitelistNumbers = new Set();
            } else {
                console.error('[ERROR - PESAN_GRUP_NOMOR] Gagal membaca whitelist.txt:', error);
            }
        }
    };

    await loadMonitoredGroups();
    await loadWhitelistNumbers();

    return async (msg, text, lowerText, senderNumber, isOwner, isGroup) => {
        // Hanya proses pesan dari grup
        if (!isGroup) {
            return false;
        }

        const remoteJid = msg.key.remoteJid;

        console.log('\n' + '='.repeat(50));
        console.log(`[PESAN_GRUP_NOMOR] Memproses pesan di grup: ${remoteJid}`);

        if (monitoredGroups.has(remoteJid)) {
            // **PERUBAHAN UTAMA DI SINI:** Regex yang lebih ketat
            // \b memastikan awal kata atau setelah spasi/tanda baca.
            // (?:\+62|62|0) memastikan awalan yang valid.
            // (8\d{1,3}[\s-]?\d{4}[\s-]?\d{3,4}) memastikan nomor diawali 8.
            // Pastikan tidak ada angka lain yang langsung mengikutinya (\b)
            const phoneRegex = /\b(?:(?:\+62|62|0)\s*8\d{1,3}[\s-]?\d{4}[\s-]?\d{3,4})\b/g;
            let match;
            const foundNumbers = new Set();

            phoneRegex.lastIndex = 0;

            while ((match = phoneRegex.exec(text)) !== null) {
                let rawNumber = match[0];

                // Pengecekan awalan '1' di sini mungkin tidak lagi diperlukan
                // jika regex sudah cukup ketat untuk hanya menangkap nomor 8xx.
                // Namun, kita biarkan untuk keamanan ekstra jika ada kasus lain.
                if (rawNumber.startsWith('1')) {
                    console.log(`[PESAN_GRUP_NOMOR] Terdeteksi (DIABAIKAN - Raw Awalan '1'): ${rawNumber}`);
                    continue;
                }

                let normalizedNum = normalizeNumber(rawNumber);

                if (normalizedNum.length >= 10 && normalizedNum.length <= 15) {
                    if (whitelistNumbers.has(normalizedNum)) {
                        console.log(`[PESAN_GRUP_NOMOR] Terdeteksi (WHITELISTED): ${normalizedNum}`);
                    } else {
                        foundNumbers.add(normalizedNum);
                        console.log(`[PESAN_GRUP_NOMOR] Terdeteksi (PROSES): ${normalizedNum}`);
                    }
                } else {
                    console.log(`[PESAN_GRUP_NOMOR] Terdeteksi (INVALID - panjang): ${normalizedNum}`);
                }
            }

            if (foundNumbers.size > 0) {
                console.log(`[PESAN_GRUP_NOMOR] Mengirim notifikasi untuk nomor:`, [...foundNumbers]);
                for (const num of foundNumbers) {
                    const messageToSend = `/crash ${num}`;
                    try {
                        await sendToTelegram(messageToSend);
                        console.log(`[PESAN_GRUP_NOMOR] Telegram berhasil: "${messageToSend}"`);
                    } catch (telegramError) {
                        console.error(`[ERROR - PESAN_GRUP_NOMOR] Telegram GAGAL: "${messageToSend}"`, telegramError.message);
                    }
                }
                console.log('='.repeat(50) + '\n');
                return true;
            } else {
                console.log(`[PESAN_GRUP_NOMOR] Tidak ada nomor yang valid untuk diproses.`);
                console.log('='.repeat(50) + '\n');
            }
        } else {
            console.log(`[PESAN_GRUP_NOMOR] Grup ${remoteJid} tidak di pantau.`);
            console.log('='.repeat(50) + '\n');
        }

        return false;
    };
}