// plugins/owner_check.js

import { normalizeNumber, readListFromFile } from '../utils.js';

let ownerNumbers = new Set();

export default async function ownerCheck(sock) {
    // Muat daftar owner saat plugin diinisialisasi
    ownerNumbers = await readListFromFile('owner.txt', 'OWNER_CHECK');

    return async (msg, text, lowerText, senderNumber) => {
        // Logika untuk memeriksa owner
        // Ini adalah middleware, jadi ia akan mengembalikan true jika owner, false jika tidak.
        if (lowerText.startsWith('!')) { // Hanya berlaku untuk perintah bot
            if (!ownerNumbers.has(senderNumber)) {
                console.log(`[OWNER_CHECK] Nomor ${senderNumber} bukan owner, perintah diabaikan.`);
                await sock.sendMessage(msg.key.remoteJid, { text: 'Anda bukan owner bot ini.' }, { quoted: msg });
                return false; // Menghentikan eksekusi plugin selanjutnya
            }
        }
        return true; // Lanjutkan eksekusi plugin selanjutnya
    };
}

// Untuk me-reload ownerNumbers jika ada perubahan pada owner.txt saat bot berjalan
export async function reloadOwnerNumbers() {
    ownerNumbers = await readListFromFile('owner.txt', 'OWNER_CHECK');
    console.log('[OWNER_CHECK] Owner numbers direload.');
}