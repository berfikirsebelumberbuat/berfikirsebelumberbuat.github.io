// plugins/group_management.js

import { normalizeNumber } from '../utils.js';

export default async function groupManagementPlugin(sock) {
    console.log('[PLUGIN] Group Management siap.');

    return async (msg, text, lowerText, senderNumber, isOwner, isGroup) => {
        // Plugin ini hanya berfungsi di dalam grup
        if (!isGroup) {
            return false;
        }

        const remoteJid = msg.key.remoteJid;
        const metadata = await sock.groupMetadata(remoteJid).catch(e => {
            console.error('[ERROR - GROUP_MANAGEMENT] Gagal mengambil metadata grup:', e);
            return null;
        });

        if (!metadata) {
            await sock.sendMessage(remoteJid, { text: 'Tidak dapat mengambil info grup ini.' }, { quoted: msg });
            return true; // Pesan ditangani
        }

        // Cek apakah bot adalah admin di grup ini
        const botId = sock.user.id.split(':')[0] + '@s.whatsapp.net'; // ID bot
        const botParticipant = metadata.participants.find(p => p.id === botId);
        const isBotAdmin = botParticipant && botParticipant.admin === 'admin';

        // --- Perintah Owner Saja ---
        // Semua perintah manajemen grup ini hanya untuk owner bot
        if (lowerText.startsWith('!kick') ||
            lowerText.startsWith('!addadmin') ||
            lowerText.startsWith('!deladmin') ||
            lowerText.startsWith('!cekadmin') ||
            lowerText.startsWith('!addmember')) {

            if (!isOwner) {
                return false; // Owner check sudah mengirim pesan "Anda bukan owner"
            }
        }


        // --- Pengecekan Izin Bot Admin untuk Perintah Modifikasi Anggota ---
        // Perintah ini (kick, addadmin, deladmin, addmember) memerlukan bot sebagai admin
        if ((lowerText.startsWith('!kick') ||
             lowerText.startsWith('!addadmin') ||
             lowerText.startsWith('!deladmin') ||
             lowerText.startsWith('!addmember')) && !isBotAdmin) {
            await sock.sendMessage(remoteJid, { text: 'Maaf, saya bukan admin di grup ini sehingga tidak bisa melakukan perintah tersebut.' }, { quoted: msg });
            return true;
        }

        // Helper untuk mendapatkan target JID dari mention/reply/argumen
        const getTargetJid = (message) => {
            if (message.message?.extendedTextMessage?.contextInfo?.mentionedJid?.length > 0) {
                return message.message.extendedTextMessage.contextInfo.mentionedJid[0];
            }
            if (message.message?.extendedTextMessage?.contextInfo?.participant) { // Reply ke seseorang
                return message.message.extendedTextMessage.contextInfo.participant;
            }
            return null; // Return null if not found by mention or reply
        };


        // --- Logika !kick ---
        if (lowerText.startsWith('!kick')) {
            const targetJid = getTargetJid(msg);

            if (!targetJid) {
                await sock.sendMessage(remoteJid, { text: 'Gunakan !kick dengan me-reply pesan anggota atau tag orangnya (@user).' }, { quoted: msg });
                return true;
            }

            const targetNormalizedJid = normalizeNumber(targetJid.split('@')[0]) + '@s.whatsapp.net';

            // Cek apakah target adalah bot itu sendiri
            if (targetNormalizedJid === botId) {
                await sock.sendMessage(remoteJid, { text: 'Saya tidak bisa mengeluarkan diri sendiri!' }, { quoted: msg });
                return true;
            }

            const targetParticipant = metadata.participants.find(p => p.id === targetNormalizedJid);
            if (!targetParticipant) {
                await sock.sendMessage(remoteJid, { text: 'Anggota tersebut tidak ditemukan di grup ini.' }, { quoted: msg });
                return true;
            }

            // Cek apakah target adalah admin grup, owner grup, atau owner bot
            if (targetParticipant.admin === 'admin' || targetParticipant.admin === 'superadmin') {
                await sock.sendMessage(remoteJid, { text: 'Maaf, saya tidak bisa mengeluarkan admin atau owner grup lain.' }, { quoted: msg });
                return true;
            }

            try {
                await sock.groupParticipantsUpdate(remoteJid, [targetNormalizedJid], 'remove');
                await sock.sendMessage(remoteJid, { text: `Anggota ${targetNormalizedJid.split('@')[0]} telah dikeluarkan.` }, { quoted: msg });
                console.log(`[GROUP_MANAGEMENT] Anggota ${targetNormalizedJid.split('@')[0]} dikeluarkan dari ${metadata.subject}`);
            } catch (error) {
                console.error('[ERROR - GROUP_MANAGEMENT] Gagal mengeluarkan anggota:', error);
                await sock.sendMessage(remoteJid, { text: 'Terjadi kesalahan saat mencoba mengeluarkan anggota.' }, { quoted: msg });
            }
            return true;
        }

        // --- Logika !addadmin ---
        if (lowerText.startsWith('!addadmin')) {
            const targetJid = getTargetJid(msg);

            if (!targetJid) {
                await sock.sendMessage(remoteJid, { text: 'Gunakan !addadmin dengan me-reply pesan anggota atau tag orangnya (@user).' }, { quoted: msg });
                return true;
            }

            const targetNormalizedJid = normalizeNumber(targetJid.split('@')[0]) + '@s.whatsapp.net';

            const targetParticipant = metadata.participants.find(p => p.id === targetNormalizedJid);
            if (!targetParticipant) {
                await sock.sendMessage(remoteJid, { text: 'Anggota tersebut tidak ditemukan di grup ini.' }, { quoted: msg });
                return true;
            }

            if (targetParticipant.admin) { // Jika sudah admin atau owner
                await sock.sendMessage(remoteJid, { text: 'Anggota tersebut sudah menjadi admin atau owner grup.' }, { quoted: msg });
                return true;
            }

            try {
                await sock.groupParticipantsUpdate(remoteJid, [targetNormalizedJid], 'promote');
                await sock.sendMessage(remoteJid, { text: `Anggota ${targetNormalizedJid.split('@')[0]} telah diangkat menjadi admin.` }, { quoted: msg });
                console.log(`[GROUP_MANAGEMENT] Anggota ${targetNormalizedJid.split('@')[0]} diangkat jadi admin di ${metadata.subject}`);
            } catch (error) {
                console.error('[ERROR - GROUP_MANAGEMENT] Gagal mengangkat anggota menjadi admin:', error);
                await sock.sendMessage(remoteJid, { text: 'Terjadi kesalahan saat mencoba mengangkat anggota menjadi admin. Pastikan bot memiliki izin yang cukup.' }, { quoted: msg });
            }
            return true;
        }

        // --- Logika !deladmin ---
        if (lowerText.startsWith('!deladmin')) {
            const targetJid = getTargetJid(msg);

            if (!targetJid) {
                await sock.sendMessage(remoteJid, { text: 'Gunakan !deladmin dengan me-reply pesan anggota atau tag orangnya (@user).' }, { quoted: msg });
                return true;
            }

            const targetNormalizedJid = normalizeNumber(targetJid.split('@')[0]) + '@s.whatsapp.net';

            const targetParticipant = metadata.participants.find(p => p.id === targetNormalizedJid);
            if (!targetParticipant) {
                await sock.sendMessage(remoteJid, { text: 'Anggota tersebut tidak ditemukan di grup ini.' }, { quoted: msg });
                return true;
            }

            if (!targetParticipant.admin) { // Jika bukan admin
                await sock.sendMessage(remoteJid, { text: 'Anggota tersebut bukan admin.' }, { quoted: msg });
                return true;
            }
            if (targetParticipant.admin === 'superadmin') { // Jika owner grup
                 await sock.sendMessage(remoteJid, { text: 'Tidak bisa menurunkan owner grup.' }, { quoted: msg });
                return true;
            }
            if (targetNormalizedJid === botId) {
                await sock.sendMessage(remoteJid, { text: 'Saya tidak bisa menurunkan status admin saya sendiri.' }, { quoted: msg });
                return true;
            }


            try {
                await sock.groupParticipantsUpdate(remoteJid, [targetNormalizedJid], 'demote');
                await sock.sendMessage(remoteJid, { text: `Anggota ${targetNormalizedJid.split('@')[0]} telah diturunkan menjadi member.` }, { quoted: msg });
                console.log(`[GROUP_MANAGEMENT] Anggota ${targetNormalizedJid.split('@')[0]} diturunkan jadi member di ${metadata.subject}`);
            } catch (error) {
                console.error('[ERROR - GROUP_MANAGEMENT] Gagal menurunkan anggota menjadi member:', error);
                await sock.sendMessage(remoteJid, { text: 'Terjadi kesalahan saat mencoba menurunkan anggota. Pastikan bot memiliki izin yang cukup.' }, { quoted: msg });
            }
            return true;
        }

        // --- Logika !cekadmin ---
        if (lowerText === '!cekadmin') {
            let adminList = [];
            for (const participant of metadata.participants) {
                if (participant.admin === 'admin' || participant.admin === 'superadmin') {
                    adminList.push({
                        id: participant.id,
                        name: participant.id.split('@')[0] // Nama akan jadi nomor jika tidak ada kontak
                    });
                }
            }

            let responseText = `*Admin Grup : ${metadata.subject}*\n\n`;
            if (adminList.length === 0) {
                responseText += 'Tidak ada admin ditemukan.';
            } else {
                for (const admin of adminList) {
                    responseText += `Nomor : ${admin.name}\n`;
                }
            }
            await sock.sendMessage(remoteJid, { text: responseText }, { quoted: msg });
            console.log(`[GROUP_MANAGEMENT] Daftar admin dikirim ke ${remoteJid}`);
            return true;
        }

        // --- Logika !addmember ---
        if (lowerText.startsWith('!addmember ')) {
            const parts = text.split(' ');
            if (parts.length < 2) {
                await sock.sendMessage(remoteJid, { text: 'Format salah. Gunakan: !addmember <nomor_whatsapp>' }, { quoted: msg });
                return true;
            }

            let numberToAdd = parts[1].trim();
            const targetNormalizedJid = normalizeNumber(numberToAdd) + '@s.whatsapp.net';

            // Cek apakah nomor yang ditambahkan adalah bot itu sendiri
            if (targetNormalizedJid === botId) {
                 await sock.sendMessage(remoteJid, { text: 'Tidak bisa menambahkan bot itu sendiri.' }, { quoted: msg });
                 return true;
            }


            // Cek apakah nomor sudah ada di grup
            const existingParticipant = metadata.participants.find(p => p.id === targetNormalizedJid);
            if (existingParticipant) {
                await sock.sendMessage(remoteJid, { text: `Nomor ${targetNormalizedJid.split('@')[0]} sudah ada di grup ini.` }, { quoted: msg });
                return true;
            }

            try {
                const response = await sock.groupParticipantsUpdate(remoteJid, [targetNormalizedJid], 'add');
                // Baileys akan memberikan '200' jika sukses, atau error jika gagal
                if (response[0]?.status === '200') {
                    await sock.sendMessage(remoteJid, { text: `Nomor ${targetNormalizedJid.split('@')[0]} telah ditambahkan ke grup.` }, { quoted: msg });
                    console.log(`[GROUP_MANAGEMENT] Anggota ${targetNormalizedJid.split('@')[0]} ditambahkan ke ${metadata.subject}`);
                } else if (response[0]?.status === '403') {
                     // Ini bisa terjadi jika link undangan tidak valid atau pengguna harus menerima undangan
                    await sock.sendMessage(remoteJid, { text: `Gagal menambahkan nomor ${targetNormalizedJid.split('@')[0]}. Mungkin perlu undangan.` }, { quoted: msg });
                } else if (response[0]?.status === '400') {
                    // Sering terjadi jika nomor tidak valid WA atau tidak bisa ditambahkan
                    await sock.sendMessage(remoteJid, { text: `Gagal menambahkan nomor ${targetNormalizedJid.split('@')[0]}. Nomor tidak valid atau ada batasan.` }, { quoted: msg });
                }
                else {
                     await sock.sendMessage(remoteJid, { text: `Terjadi kesalahan saat menambahkan nomor ${targetNormalizedJid.split('@')[0]}. Status: ${response[0]?.status || 'Tidak diketahui'}` }, { quoted: msg });
                }

            } catch (error) {
                console.error('[ERROR - GROUP_MANAGEMENT] Gagal menambahkan anggota:', error);
                await sock.sendMessage(remoteJid, { text: 'Terjadi kesalahan saat mencoba menambahkan anggota. Pastikan bot memiliki izin yang cukup atau coba lagi.' }, { quoted: msg });
            }
            return true;
        }


        return false; // Pesan ini tidak ditangani oleh plugin ini
    };
}