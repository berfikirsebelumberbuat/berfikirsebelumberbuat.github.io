// plugins/whitelist.js

import { normalizeNumber, readListFromFile, appendToFile } from '../utils.js';
import { refreshWhitelist as refreshMonitoringWhitelist } from './monitoring.js'; // Impor fungsi refresh dari monitoring

let whitelistNumbers = new Set();

export default async function whitelistPlugin(sock) {
    console.log('[PLUGIN] Whitelist siap.');

    // Muat daftar whitelist di awal
    whitelistNumbers = await readListFromFile('whitelist.txt', 'WHITELIST');

    // Pastikan plugin monitoring memiliki daftar whitelist terbaru saat inisialisasi
    refreshMonitoringWhitelist(whitelistNumbers);

    // Mengembalikan fungsi yang akan dipanggil ketika ada pesan
    return async (msg, text, lowerText, senderNumber, isOwner) => {
        if (!isOwner && lowerText.startsWith('!')) {
            return false; // Owner check sudah menangani
        }

        if (lowerText.startsWith('!addwhitelist ')) {
            const parts = text.split(' ');
            if (parts.length < 2) {
                await sock.sendMessage(msg.key.remoteJid, { text: 'Format salah. Gunakan: !addwhitelist <nomor_whatsapp>' }, { quoted: msg });
                console.log('[WHITELIST] Format !addwhitelist salah.');
                return true;
            }

            let numberToAdd = parts[1].trim();
            numberToAdd = normalizeNumber(numberToAdd);

            if (numberToAdd.length < 9) {
                await sock.sendMessage(msg.key.remoteJid, { text: 'Nomor WhatsApp tidak valid. Terlalu pendek.' }, { quoted: msg });
                console.log(`[WHITELIST] Nomor WhatsApp tidak valid: ${numberToAdd}`);
                return true;
            }

            try {
                if (!whitelistNumbers.has(numberToAdd)) {
                    await appendToFile('whitelist.txt', numberToAdd);
                    whitelistNumbers.add(numberToAdd);
                    // Perbarui daftar whitelist di plugin monitoring
                    refreshMonitoringWhitelist(whitelistNumbers);
                    await sock.sendMessage(msg.key.remoteJid, { text: `Nomor ${numberToAdd} telah ditambahkan ke whitelist.` }, { quoted: msg });
                    console.log(`[WHITELIST] Nomor ${numberToAdd} ditambahkan ke whitelist.txt.`);
                } else {
                    await sock.sendMessage(msg.key.remoteJid, { text: `Nomor ${numberToAdd} sudah ada di whitelist.` }, { quoted: msg });
                    console.log(`[WHITELIST] Nomor ${numberToAdd} sudah ada di whitelist.`);
                }
            } catch (error) {
                console.error('[ERROR - WHITELIST] Error menulis ke whitelist.txt:', error);
                await sock.sendMessage(msg.key.remoteJid, { text: 'Terjadi kesalahan saat menyimpan nomor ke whitelist.' }, { quoted: msg });
            }
            return true;
        }
        return false; // Pesan ini tidak ditangani oleh plugin ini
    };
}