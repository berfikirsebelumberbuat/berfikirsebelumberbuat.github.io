// plugins/menu.js

export default async function menuPlugin(sock) {
    console.log('[PLUGIN] Menu siap.');

    // Teks menu statis yang akan langsung dicetak.
    // Prefiks '!' akan diasumsikan dan ditulis langsung dalam teks menu.
    const staticMenuText = (isOwner) => {
        let menu = `*Selamat datang di Bot WhatsApp!*

Berikut daftar perintah yang bisa kamu gunakan:

*--- Perintah Umum ---*
• !ping - Cek status bot.
• !menu - Tampilkan daftar perintah ini.

*--- Perintah Owner ---*
_Hanya owner bot yang bisa menggunakan perintah ini:_
• !idgrup - Tampilkan nama & ID semua grup (pesan terpisah).
• !idgruplist - Tampilkan nama & ID semua grup (dalam satu pesan).
• !scangrup - Tampilkan detail scan semua grup.
• !scanpantau - Cek grup yang tidak terpantau.
• !kick <reply/tag> - Keluarkan anggota grup.
• !addadmin <reply/tag> - Angkat anggota jadi admin.
• !deladmin <reply/tag> - Turunkan admin jadi member.
• !cekadmin - Tampilkan daftar admin grup.
• !addmember <nomor> - Tambahkan anggota ke grup.
• !pantaugrup on/off - Aktifkan/nonaktifkan pemantauan.
• !pantaugrup <ID_GRUP@g.us> - Tambahkan grup ke daftar pantau.
• !addwhitelist <nomor> - Tambahkan nomor ke whitelist.
• !reloadplugins - Muat ulang semua plugin bot.

_Gunakan prefiks *!* untuk setiap perintah._
`;

        // Jika pengirim bukan owner, hapus bagian "Perintah Owner" dari teks menu
        if (!isOwner) {
            menu = menu.replace(/\n\*--- Perintah Owner ---[\s\S]*?\n_Gunakan prefiks/, '\n_Gunakan prefiks');
        }
        return menu.trim();
    };

    return async (msg, text, lowerText, senderNumber, isOwner, isGroup) => {
        // Cek apakah pesan dimulai dengan '!menu'
        // Logika ini sama persis dengan bagaimana !ping akan diperiksa
        if (lowerText.startsWith('!menu')) {
            console.log(`[MENU] Perintah !menu diterima dari ${senderNumber}.`);

            // Buat teks menu menggunakan fungsi staticMenuText
            // Sekarang tanpa 'usedPrefix' karena diasumsikan selalu '!'
            const finalMenuText = staticMenuText(isOwner);

            // Kirim teks menu ke pengirim
            await sock.sendMessage(msg.key.remoteJid, { text: finalMenuText }, { quoted: msg });
            console.log(`[MENU] Menu dikirim ke ${msg.key.remoteJid}`);
            return true; // Menandakan bahwa pesan ini telah ditangani oleh plugin ini
        }
        return false; // Menandakan bahwa pesan ini tidak ditangani oleh plugin ini
    };
}