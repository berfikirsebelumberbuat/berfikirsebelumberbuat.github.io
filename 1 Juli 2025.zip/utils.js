// utils.js

import { promises as fs } from 'fs'; // Gunakan promises as fs untuk menghindari callback hell
import path from 'path'; // Import modul path untuk resolusi path
import fetch from 'node-fetch';
import chokidar from 'chokidar'; // Import chokidar untuk memantau perubahan file

import { TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID } from './config.js'; // Ambil dari config

/**
 * Normalizes a phone number to '62' format without non-numeric characters.
 * @param {string} number The raw phone number.
 * @returns {string} The normalized phone number.
 */
export function normalizeNumber(number) {
    let normalized = number.replace(/[^0-9]/g, '');
    if (normalized.startsWith('0')) {
        normalized = '62' + normalized.substring(1);
    }
    console.log(`[DEBUG - Normalize] Raw: ${number} -> Normalized: ${normalized}`);
    return normalized;
}

/**
 * Sends a message to Telegram.
 * @param {string} message The message to send.
 */
export async function sendToTelegram(message) {
    const url = `https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`;
    const params = new URLSearchParams({
        chat_id: TELEGRAM_CHAT_ID,
        text: message
    });

    console.log(`[DEBUG - Telegram] Mengirim request ke: ${url}?${params.toString()}`);
    try {
        const response = await fetch(url, { method: 'POST', body: params });
        const data = await response.json();
        console.log('[DEBUG - Telegram] Respon dari API Telegram:', data);

        if (!data.ok) {
            console.error('[ERROR - Telegram] Gagal mengirim ke Telegram:', data);
            if (data.description) {
                console.error('[ERROR - Telegram] Pesan error Telegram:', data.description);
            }
        } else {
            console.log('[INFO - Telegram] Pesan berhasil terkirim ke Telegram.');
        }
    } catch (error) {
        console.error('[ERROR - Telegram] Error saat mengirim ke Telegram:', error);
    }
}

/**
 * Reads a list of items from a file, one item per line.
 * Creates an empty file if it doesn't exist.
 * @param {string} filename The name of the file (e.g., 'whitelist.txt').
 * @param {string} logName A friendly name for logging.
 * @returns {Promise<Set<string>>} A Set containing the items.
 */
export async function readListFromFile(filename, logName) {
    const filePath = path.resolve(filename); // Resolusi path untuk konsistensi
    try {
        const data = await fs.readFile(filePath, 'utf8');
        const list = new Set(data.split('\n').map(item => item.trim()).filter(item => item.length > 0));
        console.log(`[${logName}] Dimuat (${list.size} item):`, [...list]);
        return list;
    } catch (error) {
        if (error.code === 'ENOENT') {
            await fs.writeFile(filePath, '', 'utf8');
            console.log(`[${logName}] File ${filename} tidak ditemukan, membuat yang baru.`);
            return new Set();
        } else {
            console.error(`[ERROR - ${logName}] Error membaca ${filename}:`, error);
            return new Set();
        }
    }
}

/**
 * Appends an item to a file, adding a newline.
 * @param {string} filename The name of the file.
 * @param {string} item The item to append.
 */
export async function appendToFile(filename, item) {
    const filePath = path.resolve(filename); // Resolusi path
    try {
        await fs.appendFile(filePath, item + '\n', 'utf8');
        console.log(`[FILE_UPDATE] Menambahkan '${item}' ke ${filename}.`);
    } catch (error) {
        console.error(`[ERROR] Gagal menulis ke ${filename}:`, error);
        throw error; // Lempar error agar bisa ditangkap di pemanggil
    }
}

/**
 * Writes (overwrites) an entire list to a file, one item per line.
 * Useful for removing items by rebuilding the file.
 * @param {string} filename The name of the file.
 * @param {Set<string>} list The Set of items to write.
 */
export async function writeListToFile(filename, list) {
    const filePath = path.resolve(filename);
    try {
        const data = Array.from(list).join('\n');
        await fs.writeFile(filePath, data, 'utf8');
        console.log(`[FILE_UPDATE] Berhasil menulis ulang ${filename} (${list.size} item).`);
    } catch (error) {
        console.error(`[ERROR] Gagal menulis ulang ${filename}:`, error);
        throw error;
    }
}

/**
 * Watches a file for changes and triggers a callback when a change is detected.
 * @param {string} filename The name of the file to watch.
 * @param {(newList: Set<string>) => void} callback The function to call with the updated Set of items.
 * @returns {chokidar.FSWatcher} The watcher instance (can be used to close later if needed).
 */
export function watchFile(filename, callback) {
    const filePath = path.resolve(filename);
    const watcher = chokidar.watch(filePath, {
        persistent: true,
        ignoreInitial: true, // Jangan picu callback saat pertama kali watcher dimulai
        awaitWriteFinish: {
            stabilityThreshold: 1000, // Tunggu 1 detik untuk memastikan penulisan selesai
            pollInterval: 100
        }
    });

    watcher.on('change', async (path) => {
        console.log(`[FILE_WATCHER] Perubahan terdeteksi di ${filename}. Memuat ulang data...`);
        try {
            const newList = await readListFromFile(filename, `Updated ${filename}`);
            callback(newList); // Panggil callback dengan daftar yang diperbarui
        } catch (error) {
            console.error(`[FILE_WATCHER_ERROR] Gagal memuat ulang ${filename}:`, error);
        }
    });

    watcher.on('error', (error) => {
        console.error(`[FILE_WATCHER_ERROR] Kesalahan watcher untuk ${filename}:`, error);
    });

    console.log(`[FILE_WATCHER] Memulai pemantauan untuk ${filename}...`);
    return watcher;
}